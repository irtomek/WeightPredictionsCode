### Description:
The software package for the AAAI submission entitled "Predicting Weights in Signed Weighted Networks is Difficult to Manipulate", submission number: 7988.

This software was used to generate experimental data summarized in Figures 9 and 10 (see Output section in this README for more details).


### Instructions:

- download the dataset from https://snap.stanford.edu/data/soc-sign-bitcoin-otc.html
- ensure the following folder structure is preserved
```
.
├── data-wsn
│   └── db
│       ├── BTCAlphaNet.csv
│       ├── EpinionNet.csv
│       ├── OTCNet.csv
│       ├── RFAnet.csv
│       └── WikiSignedNet.csv
├── requirements.txt
└── simulations.ipynb
```
- install python3.9 and pip

- go to the main folder with the files `.`

- run command `pip install -r ./requirements.txt`  to install requirements

- run command `jupyter notebook`

- open `simulations.ipynb` in the jupyter console and run all cells from top to bottom 

- the results will be saved in the `.csv` files

### Output:
- data in the `DG.csv`, `DNG.csv`, `STG.csv`, `STNG.csv` files was used in Figure 9.
- data in the `MIX.csv` file was used in Figure 10.
